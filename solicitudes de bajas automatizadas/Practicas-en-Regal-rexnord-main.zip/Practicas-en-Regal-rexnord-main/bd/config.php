<?php 

define('DB_SERVER', 'localhost');
define('DB_NAME', 'bdregal');
define('DB_USER', 'root');
define('DB_PASS', '');

 ?>